Page({
  data: {
    names: '',
    groupCount: 0,
    groupedNames: []
  },
  onInputChange(e) {
    this.setData({
      names: e.detail.value
    });
  },
  onGroupCountChange(e) {
    this.setData({
      groupCount: parseInt(e.detail.value, 10) || 0
    });
  },
  groupNames() {
    let names = this.data.names.split('，').filter(Boolean);
    let groupCount = this.data.groupCount;
    
    if (groupCount <= 0 || groupCount > names.length) {
      wx.showToast({
        title: '分组数目不合法',
        icon: 'none'
      });
      return;
    }
    
    let groups = Array.from({ length: groupCount }, () => []);
    names = names.sort(() => Math.random() - 0.5);
    
    names.forEach((name, index) => {
      groups[index % groupCount].push(name);
    });
   
    this.setData({
      groupedNames: groups
    });
  }
});