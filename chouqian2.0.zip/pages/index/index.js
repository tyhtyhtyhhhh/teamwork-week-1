Page({
  goToSortPage() {
    wx.navigateTo({
      url: '/pages/sort/sort'
    });
  },
  goToGroupPage() {
    wx.navigateTo({
      url: '/pages/group/group'
    });
  }
});
