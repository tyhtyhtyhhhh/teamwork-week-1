Page({
  data: {
    names: '',
    sortedNames: ''
  },
  onInputChange(e) {
    this.setData({
      names: e.detail.value
    });
  },
  sortNames() {
    let names = this.data.names.split('，').filter(Boolean);
    names = names.sort(() => Math.random() - 0.5);
    this.setData({
      sortedNames: names.join('，')
    });
  }
});