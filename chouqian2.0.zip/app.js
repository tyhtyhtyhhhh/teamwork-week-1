App({
  onLaunch() {
    // 小程序启动时的逻辑
  }
});
